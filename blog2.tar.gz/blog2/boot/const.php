<?php

// фактически - это настройка среды: в unix - '/', в windows - '\'
const DIR_SEPARATOR = '/';
// директория проекта
const ROOT_DIR = '/home/victor/php/php_zone_prof/blog2/';
// директория внешних библиотек
const SRC_DIR = ROOT_DIR . 'src/';
const BLOCK_ERROR = 'Ошибка! Переменная не определена!';

const ARTICLES_PER_PAGE = 3;
const MATCHES = 'matches';
const REDIS_SEPARATOR = ',';
const USER = 'user';
