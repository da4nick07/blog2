<?php
/*
 *  init для html
 */

require_once 'init.php';

require_once ROOT_DIR . 'lib/html_functions.php';



