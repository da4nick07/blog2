<?php
namespace Exceptions;

use Exception;

class InvalidArgumentException extends Exception
{
}
