<?php
namespace Exceptions;

use Exception;

class Forbidden extends Exception
{
}

