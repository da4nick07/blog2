<?php
namespace Exceptions;

use Exception;

class MRedisExeption extends Exception
{
}
