<?php

return [
    'db' => [
        'driver' => 'mysql',
        'host' => 'localhost',
        'port' => '3306',
        'dbname' => 'blog_db2',
        'user' => 'root',
        'password' => '@root',
    ],
    'redis' => [
        'host' => 'localhost',
        'port' => '6379',
    ]
];