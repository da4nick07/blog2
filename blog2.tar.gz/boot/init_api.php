<?php
/*
 *  init для api
 */

require_once 'init.php';

require_once ROOT_DIR . 'lib/api_functions.php';
