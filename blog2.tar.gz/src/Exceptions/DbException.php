<?php
namespace Exceptions;

use Exception;

class DbException extends Exception
{
}